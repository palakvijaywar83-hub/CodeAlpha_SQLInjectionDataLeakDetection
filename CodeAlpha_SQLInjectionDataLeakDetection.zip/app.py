"""
Demo: Secure Cloud Data System
CodeAlpha Cloud Computing Internship — Task 2

Run: python app.py
"""

from secure_db import SecureDB
from sql_injection_detector import InjectionDetected

MASTER_KEY = "S3cure-Master-Key-Change-In-Prod"  # in real deployment: env var / cloud secret manager


def banner(text):
    print("\n" + "=" * 60)
    print(text)
    print("=" * 60)


def main():
    db = SecureDB(master_password=MASTER_KEY)

    banner("1. Registering legitimate users (AES-256 encrypted storage)")
    try:
        db.register_user("palak_dev", "MyP@ssw0rd!", "palak@example.com", "9999999999")
        print("User 'palak_dev' registered successfully.")
    except ValueError as e:
        print(e)

    banner("2. Reading back user (data decrypted on the fly)")
    user = db.get_user("palak_dev")
    print(user)

    banner("3. Verifying correct login")
    print("Login success:", db.verify_login("palak_dev", "MyP@ssw0rd!"))

    banner("4. Verifying wrong password")
    print("Login success:", db.verify_login("palak_dev", "wrongpass"))

    banner("5. Simulating SQL Injection attacks (these get BLOCKED + logged)")
    attacks = [
        "admin' OR '1'='1",
        "'; DROP TABLE users; --",
        "' UNION SELECT username, password_enc FROM users --",
        "admin'--",
        "1' AND SLEEP(5)--",
    ]
    for payload in attacks:
        try:
            db.verify_login(payload, "irrelevant", user_ip="203.0.113.42")
            print(f"[NOT DETECTED] {payload}")
        except InjectionDetected as e:
            print(f"[BLOCKED] {payload}  ->  {e}")

    banner("6. Check injection_attempts.log for the audit trail")
    with open("injection_attempts.log") as f:
        print(f.read())

    db.close()


if __name__ == "__main__":
    main()
