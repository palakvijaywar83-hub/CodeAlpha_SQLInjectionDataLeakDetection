"""
SecureDB: SQLite wrapper that
 - ONLY ever uses parameterized queries (real SQLi prevention)
 - runs every input through the injection detector first (monitoring/alerting)
 - encrypts sensitive fields (password, email, phone) with AES-256-GCM before storage
"""

import sqlite3
import hashlib
from datetime import datetime

from encryption import make_cipher
from sql_injection_detector import scan_dict, InjectionDetected


class SecureDB:
    def __init__(self, db_path="secure_users.db", master_password="change_this_master_key"):
        self.conn = sqlite3.connect(db_path)
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.cipher = make_cipher(master_password)
        self._init_schema()

    def _init_schema(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_enc TEXT NOT NULL,
                email_enc TEXT NOT NULL,
                phone_enc TEXT,
                created_at TEXT NOT NULL
            )
        """)
        self.conn.commit()

    # ---------- WRITE ----------
    def register_user(self, username, password, email, phone=None, user_ip="local"):
        # Step 1: detect obvious injection attempts and block/log them
        scan_dict({"username": username, "password": password, "email": email, "phone": phone},
                  user_ip=user_ip)

        # Step 2: encrypt sensitive fields (AES-256-GCM)
        password_enc = self.cipher.encrypt(password)
        email_enc = self.cipher.encrypt(email)
        phone_enc = self.cipher.encrypt(phone) if phone else None

        # Step 3: parameterized query -> structurally immune to SQL injection
        try:
            self.conn.execute(
                "INSERT INTO users (username, password_enc, email_enc, phone_enc, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (username, password_enc, email_enc, phone_enc, datetime.utcnow().isoformat()),
            )
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            raise ValueError(f"Username '{username}' already exists")

    # ---------- READ ----------
    def get_user(self, username, user_ip="local"):
        scan_dict({"username": username}, user_ip=user_ip)

        cur = self.conn.execute(
            "SELECT id, username, password_enc, email_enc, phone_enc, created_at "
            "FROM users WHERE username = ?",
            (username,),
        )
        row = cur.fetchone()
        if not row:
            return None

        return {
            "id": row[0],
            "username": row[1],
            "password": self.cipher.decrypt(row[2]),
            "email": self.cipher.decrypt(row[3]),
            "phone": self.cipher.decrypt(row[4]) if row[4] else None,
            "created_at": row[5],
        }

    def verify_login(self, username, password, user_ip="local"):
        scan_dict({"username": username, "password": password}, user_ip=user_ip)
        user = self.get_user(username, user_ip=user_ip)
        if user and user["password"] == password:
            return True
        return False

    def close(self):
        self.conn.close()
