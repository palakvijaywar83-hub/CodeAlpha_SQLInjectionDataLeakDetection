# CodeAlpha_SQLInjectionDataLeakDetection

**CodeAlpha Cloud Computing Internship — Task 2: Detecting Data Leaks Using SQL Injection**

A secure cloud-style data system that:
- **Blocks SQL Injection** via two layers: a pattern-based real-time detector (logs/alerts) + parameterized queries (structural prevention, the actual fix).
- **Encrypts sensitive user data** (password, email, phone) using **AES-256-GCM** before it ever touches the database. Keys derived via PBKDF2-HMAC-SHA256 (200,000 iterations).

## Project Structure
```
├── encryption.py              # AES-256-GCM encrypt/decrypt (key derivation via PBKDF2)
├── sql_injection_detector.py  # Regex-based SQLi pattern detector + logger
├── secure_db.py                # SQLite wrapper: detector + encryption + parameterized queries
├── app.py                      # Runnable demo (registration, login, simulated attacks)
├── requirements.txt
└── injection_attempts.log     # Auto-generated audit log of blocked attacks
```

## How it works
1. Every input (username, password, email, phone) is first scanned by `sql_injection_detector.py` against known SQLi patterns (`OR 1=1`, `UNION SELECT`, `; DROP TABLE`, `SLEEP()`, comment injection, etc.). Matches are logged with timestamp, IP, field, and payload, then rejected.
2. Sensitive fields are encrypted with AES-256-GCM before storage — even a raw DB dump/leak reveals no readable credentials.
3. All DB access uses **parameterized queries** (`?` placeholders) — the actual mechanism that prevents SQL injection, regardless of what gets past the detector.

## Run it
```bash
pip install -r requirements.txt
python app.py
```

This will:
- Register a user with encrypted storage
- Show decrypted read-back
- Test valid/invalid login
- Fire 5 real-world SQLi payloads and show them getting blocked
- Print the audit log

## Notes
- `MASTER_KEY` in `app.py` is hardcoded for demo purposes. In production, load it from an environment variable or a cloud secret manager (AWS Secrets Manager / GCP Secret Manager / Azure Key Vault).
- `salt.bin` and `secure_users.db` are generated at runtime — don't need to be committed (add to `.gitignore`).

## Internship
Built as part of the **CodeAlpha Cloud Computing Internship** (July 2026).
