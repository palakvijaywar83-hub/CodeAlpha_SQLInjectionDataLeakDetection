"""
AES-256-GCM encryption for sensitive user data (passwords, PII, emails).
GCM = authenticated encryption (confidentiality + tamper detection).
"""

import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes


class AES256Cipher:
    """One cipher instance per app, built from a master key (env var / secret)."""

    def __init__(self, master_password: str, salt: bytes):
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,          # 256-bit key -> AES-256
            salt=salt,
            iterations=200_000,
        )
        self.key = kdf.derive(master_password.encode())
        self.aesgcm = AESGCM(self.key)

    def encrypt(self, plaintext: str) -> str:
        nonce = os.urandom(12)
        ct = self.aesgcm.encrypt(nonce, plaintext.encode(), None)
        return base64.b64encode(nonce + ct).decode()

    def decrypt(self, token: str) -> str:
        blob = base64.b64decode(token.encode())
        nonce, ct = blob[:12], blob[12:]
        return self.aesgcm.decrypt(nonce, ct, None).decode()


def get_or_create_salt(path: str = "salt.bin") -> bytes:
    if os.path.exists(path):
        with open(path, "rb") as f:
            return f.read()
    salt = os.urandom(16)
    with open(path, "wb") as f:
        f.write(salt)
    return salt


def make_cipher(master_password: str, salt_path: str = "salt.bin") -> AES256Cipher:
    salt = get_or_create_salt(salt_path)
    return AES256Cipher(master_password, salt)
