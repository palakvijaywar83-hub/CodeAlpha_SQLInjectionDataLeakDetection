"""
SQL Injection detection layer.
Two defenses:
 1. Pattern-based detector -> flags/logs suspicious input (for monitoring/alerting).
 2. Parameterized queries (see secure_db.py) -> actually prevents injection.
Detector alone is NOT the fix; it's the alarm. Parameterization is the fix.
"""

import re
import logging
from datetime import datetime

logging.basicConfig(
    filename="injection_attempts.log",
    level=logging.WARNING,
    format="%(asctime)s | %(message)s",
)

SQLI_PATTERNS = [
    r"(\bOR\b|\bAND\b)\s+[\d\w'\"]+\s*=\s*[\d\w'\"]+",   # OR 1=1
    r"--",                                                # comment injection
    r";\s*(DROP|DELETE|UPDATE|INSERT|ALTER)\s",           # stacked queries
    r"\bUNION\b\s+\bSELECT\b",                            # UNION-based
    r"\bSLEEP\s*\(",                                      # time-based blind
    r"\bBENCHMARK\s*\(",
    r"'\s*OR\s*'1'\s*=\s*'1",
    r"xp_cmdshell",
    r"\bEXEC(UTE)?\b\s*\(",
    r"/\*.*\*/",                                          # inline comments
    r"\bWAITFOR\s+DELAY\b",
]

_compiled = [re.compile(p, re.IGNORECASE) for p in SQLI_PATTERNS]


class InjectionDetected(Exception):
    pass


def scan(user_input: str, source_field: str = "unknown", user_ip: str = "local") -> bool:
    """Returns True if input looks clean. Logs + raises if malicious pattern found."""
    if user_input is None:
        return True

    for pattern in _compiled:
        if pattern.search(str(user_input)):
            logging.warning(
                f"BLOCKED | field={source_field} | ip={user_ip} | "
                f"pattern='{pattern.pattern}' | input='{user_input[:100]}'"
            )
            raise InjectionDetected(
                f"Potential SQL injection detected in field '{source_field}'"
            )
    return True


def scan_dict(fields: dict, user_ip: str = "local") -> bool:
    for field_name, value in fields.items():
        scan(value, source_field=field_name, user_ip=user_ip)
    return True
